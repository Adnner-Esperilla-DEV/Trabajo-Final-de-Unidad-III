package com.document.lawyerfiles.ui.bandeja;

import androidx.lifecycle.ViewModel;

public class BandejaViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
