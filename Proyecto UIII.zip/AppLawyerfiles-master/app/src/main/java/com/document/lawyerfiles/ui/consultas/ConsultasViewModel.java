package com.document.lawyerfiles.ui.consultas;

import androidx.lifecycle.ViewModel;

public class ConsultasViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
