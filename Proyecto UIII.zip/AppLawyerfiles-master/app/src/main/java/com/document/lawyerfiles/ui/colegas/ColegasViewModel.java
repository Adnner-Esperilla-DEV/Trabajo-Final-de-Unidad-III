package com.document.lawyerfiles.ui.colegas;

import androidx.lifecycle.ViewModel;

public class ColegasViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
