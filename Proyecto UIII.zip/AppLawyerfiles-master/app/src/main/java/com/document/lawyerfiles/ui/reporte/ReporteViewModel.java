package com.document.lawyerfiles.ui.reporte;

import androidx.lifecycle.ViewModel;

public class ReporteViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}