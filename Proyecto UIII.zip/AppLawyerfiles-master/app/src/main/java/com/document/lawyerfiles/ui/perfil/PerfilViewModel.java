package com.document.lawyerfiles.ui.perfil;

import androidx.lifecycle.ViewModel;

public class PerfilViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
