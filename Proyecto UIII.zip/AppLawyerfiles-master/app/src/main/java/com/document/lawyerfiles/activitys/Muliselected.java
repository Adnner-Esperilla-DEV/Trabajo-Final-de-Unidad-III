package com.document.lawyerfiles.activitys;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.document.lawyerfiles.R;

public class Muliselected extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_muliselected);
    }
}
