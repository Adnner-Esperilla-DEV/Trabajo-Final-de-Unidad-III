package com.document.lawyerfiles.ui.calendario;

import androidx.lifecycle.ViewModel;

public class CalendarioViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
