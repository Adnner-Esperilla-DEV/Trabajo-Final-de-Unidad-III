package com.document.lawyerfiles.ui.archivos;

import androidx.lifecycle.ViewModel;

public class ArchivosViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
