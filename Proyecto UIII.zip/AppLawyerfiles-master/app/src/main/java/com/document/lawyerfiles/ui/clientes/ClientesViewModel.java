package com.document.lawyerfiles.ui.clientes;

import androidx.lifecycle.ViewModel;

public class ClientesViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
